﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationMinutoFeed.Entidades
{
    public class palavrasOcorrencias
    {
        public string palavra { get; set; }
        public int numroOcorrencias { get; set; }
    }
}
