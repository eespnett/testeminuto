﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationMinutoFeed.Entidades
{
    public class Item
    {
        public string title { get; set; }
        public string Link { get; set; }
        public string comments { get; set; }
        public string puDate { get; set; }
        public string Creator { get; set; }
        public string guid { get; set; }
        public List<string> Categorias { get; set; }
        public string fuidLink { get; set; }
        public string description { get; set; }
        public string commentRss { get; set; }

        public List<palavrasOcorrencias> ListPalavrasOcorrencias { get; set; }

    }
}
