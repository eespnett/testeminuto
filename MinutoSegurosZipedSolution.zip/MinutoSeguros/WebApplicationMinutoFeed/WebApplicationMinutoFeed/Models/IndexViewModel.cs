using System;
using System.Collections.Generic;
using WebApplicationMinutoFeed.Entidades;

namespace WebApplicationMinutoFeed.Models
{
    public class IndexViewModel
    {
        public List<Item> Itens { get; set; }


    }
}