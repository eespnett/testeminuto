﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using Microsoft.AspNetCore.Mvc;
using WebApplicationMinutoFeed.Entidades;
using WebApplicationMinutoFeed.Models;

namespace WebApplicationMinutoFeed.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            IndexViewModel entity = new IndexViewModel();

            List<Item> myItens = new List<Item>();
            ExtrairInformacoesRSS(myItens);

            OrdernarItens(myItens);

            entity.Itens = myItens;
            return View(entity);
        }

        private static void OrdernarItens(List<Item> myItens)
        {
            foreach (var item in myItens)
            {
                if (item.comments != "")
                {
                    string[] wordsComments = item.description.Split(' ');
                    List<string> ListWordsComments = new List<string>();

                    foreach (string arrItem in wordsComments)
                    {
                        ListWordsComments.Add(arrItem);
                    }
                    item.ListPalavrasOcorrencias = new List<palavrasOcorrencias>();
                    foreach (var item2 in ListWordsComments)
                    {


                        if (item2.Length > 3)
                        {
                            int intCoutnRepeticoes = 0;

                            intCoutnRepeticoes = ListWordsComments.Where(x => x.ToUpper() == item2.ToUpper()).Count();


                            item.ListPalavrasOcorrencias.Add(new palavrasOcorrencias() { palavra = item2, numroOcorrencias = intCoutnRepeticoes });



                        }

                        item.ListPalavrasOcorrencias = item.ListPalavrasOcorrencias.OrderByDescending(x => x.numroOcorrencias).Take(10).ToList();
                    }


                }
            }
        }

        private static void ExtrairInformacoesRSS(List<Item> myItens)
        {
            XmlDocument xmldoc = new XmlDocument();


            xmldoc.Load(Environment.CurrentDirectory.ToString() + "/Content/feedMinuto.xml");
            XmlNodeList settings = xmldoc.SelectNodes("/item");
            XmlNodeList defaults = xmldoc.GetElementsByTagName("item");


            foreach (XmlNode node in defaults)
            {
                Item currentItem = new Item();
                currentItem.Categorias = new List<string>();
                foreach (XmlNode xmlNode in node)
                {
                    switch (xmlNode.Name)
                    {


                        case "title":
                            currentItem.title = xmlNode.InnerText.ToString();
                            break;

                        case "link":
                            currentItem.Link = xmlNode.InnerText.ToString();
                            break;


                        case "comments":
                            currentItem.comments = xmlNode.InnerText.ToString();
                            break;


                        case "pubDate":
                            currentItem.puDate = xmlNode.InnerText.ToString();
                            break;

                        case "creator":
                            currentItem.Creator = xmlNode.InnerText.ToString();
                            break;

                        case "category":
                            currentItem.Categorias.Add(xmlNode.InnerText.ToString());

                            break;
                        case "guid":
                            currentItem.guid = xmlNode.InnerText.ToString();
                            break;
                        case "description":
                            currentItem.description = xmlNode.InnerText.ToString();
                            break;

                        case "commentRss":
                            currentItem.commentRss = xmlNode.InnerText.ToString();
                            break;
                        default:
                            break;
                    }


                }
                myItens.Add(currentItem);
            }
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
